#include "Path_function2.h"
#include "motor_control.h"

void pickAndplace_object1()
{
 
}
void pickAndplace_object2()
{

}

void pickAndplace_object3()
{

}
void pickAndplace_object4()
{
   
}
void pickAndplace_object5()
{
    
}

void ReturnObject1() // Special workshop
{
    
}